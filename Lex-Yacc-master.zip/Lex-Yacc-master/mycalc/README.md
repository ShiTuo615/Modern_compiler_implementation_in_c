### make
```
make
```
```
make clean
```